﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models;

namespace aspnetcore.Controllers;

public class CourseController : Controller
{

    public IActionResult Index()
    {
        List<Course> courses = new List<Course>
        {
            new Course { Id =1, Title="Asp Net Core", Description= "Desc1", Img="Img1.jpg"},
            new Course { Id =2, Title="Asp Net Core", Description= "Desc1" , Img="Img1.jpg"},
            new Course { Id =3, Title="Asp Net Core", Description= "Desc1" , Img="Img2.jpg"},
            new Course { Id =4, Title="Asp Net Core", Description= "Desc1" , Img="Img2.jpg"},
            new Course { Id =4, Title="Asp Net Cosdsdre", Description= "Desdfgdfc1" , Img="Img2.jpg"}


        };

        return View(courses);
    }

    public IActionResult List()
    {

        return View();
    }

}
